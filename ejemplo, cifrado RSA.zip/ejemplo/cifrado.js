function cifrar(texto){
	var encrypt = new JSEncrypt();

	encrypt.setPublicKey("MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDi9Fxbkrm+skThjkFcH1VLjbEf\n" + 
						"PR6bR/tjwbo/sULak36SceMZXY4E6UKlmYMCmlJ6pSm/tVQhLw+4rbpOrZe2SaP/\n" + 
						"hb8s8RAfD6ABJ1CCjjzDPH+v0tX7GdjJWJDf8BmhCoiJw9jcC7tsWc9DnDjH+O02\n" + 
						"le5HFWceRceYwVM5ywIDAQAB\n");

	var encrypted = encrypt.encrypt(texto);

	return encrypted;
}

$('form[name="f"]').submit(function(event){
	event.preventDefault();

	var encryptedPassword = cifrar($('input[name="sucursal"]').val());
	var encryptedUser = cifrar($('input[name="ip"]').val());
	
$('input[name="sucursal"]').val(btoa(encryptedPassword))
$('input[name="ip"]').val(btoa(encryptedUser))

	$.ajax({
		data: $('form[name="f"]').serialize(), 
		url: $('form[name="f"]').attr('action'), 
		type: 'POST', 
		success: function(data, status, xhr){
			console.log(data);
		}
	});
});